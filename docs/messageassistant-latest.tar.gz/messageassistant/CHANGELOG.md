# Changelog

## 1.1.4 — 2026-11-18
- **Corrected: "your own keys" means your own AI keys (the brain).** 1.1.3 put own keys in the wrong place (Google client keys — that is removed). Now the switch is where it belongs: dashboard → AI keys → **"People may use their own AI keys"** (on by default). Each person adds their own key (Gemini, Groq, OpenRouter…) on their page under **Your AI keys**, and the assistant answers *them* with *their* keys first; the system keys stay as the backup. **Google** is unchanged in spirit: every person connects **their own Google account**, and it is simply an option — a new admin switch (Settings → Connect accounts) turns Google connect off entirely.
- **A secure vault for any account.** On their page, each person now has a **Secure vault**: save a website login, an API token (Cloudflare, anything) or any secret. Secrets are stored sealed and are **never shown again** — not on the page, not in a chat. The assistant can use a saved login to **sign in and do tasks** (the password is filled in by the server; the assistant never sees it), and can see the vault's labels only.
- **Reactions, like a human.** When a message asks the assistant to do something, it now reacts to that very message with the emoji that fits — 🔍 for "look something up", 🎵 for a song, ⏰ for a reminder, ❤️ for thanks, 👍 for a plain job — before the answer arrives. Plain chat gets no reaction. Admin switch: Settings → Reactions.
- **YouTube: confirm first, then the audio.** Asking for a song or video (YouTube or YouTube Music) now first sends the **thumbnail** with the title, who it's by, the **release date** and the **length**, and asks "is this the one?" Only after the person says yes does the audio go out (in full, as voice-note parts, as before). If it's the wrong one, they can pick another match by number.
- **Audio is never a link.** When an audio file could not be attached, the sender used to fall back to texting its link — useless for people without internet, and how "the audio" arrived as links. Audio now only ever goes as the file itself; the attach waits now scale with file size so bigger voice notes get the time they need, and if sending truly fails the person gets a plain failure message, never a link.

## 1.1.3 — 2026-11-18
- **YouTube Music + full-length voice notes.** youtube_audio now also searches **YouTube Music** (source "music", or a music.youtube.com link). Audio is sent in **clear, high quality** and **in full**: the 60-minute cap is gone — anything longer than one voice note (about 15 minutes) is split and sent as **several parts, one after another** (part 1, part 2, …), up to about 6 hours.
- **Connect accounts: your own keys or the system's.** Connect was a dead end whenever the admin had not set up the system Google client ("Google connect is not set up yet"). Now each person can paste **their own** Google Client ID + secret (their own free Google Cloud project) on their page and connect with those; their connections and token refreshes run on their keys, and removing the keys disconnects them. An **admin toggle** (Settings → Connect accounts, on by default) turns own keys off, leaving only the system keys. The person's page shows which keys they are using and walks them through getting their own.

## 1.1.2 — 2026-11-18
- **YouTube by text, as a voice note.** The people using this assistant have no internet, so a YouTube link is worthless to them. Now, when someone asks for a video, song, shiur or lecture ("go to YouTube and find…"), the assistant searches YouTube itself, downloads the best match with **yt-dlp**, extracts the audio, and sends the **audio file itself** in the chat — attached to the reply like a voice note they can play. New tool **youtube_audio** (search words or a YouTube link; up to about 60 minutes); **extract_audio** accepts YouTube links too. The installer and Update now install yt-dlp and keep it fresh (older than 30 days is refreshed, since YouTube changes often); Node, which the app already runs on, is yt-dlp's JavaScript runtime. If YouTube refuses a download from the server's address, the person is told plainly instead of getting a link.

## 1.1.1 — 2026-11-18
- **News and search work again.** Web search only scraped DuckDuckGo's html page, which now answers servers with a bot-check page and zero results — so "latest news" came back "I can't pull that". Search now tries DuckDuckGo html → DuckDuckGo lite → Bing and uses the first that answers, and a new **latest_news** tool reads Google News (RSS, free, no key): top stories or a topic, with headline, source, time and summary.
- **No links for people without internet.** Most people using the assistant by text have no internet, so a link in a text is useless to them. Answers now come in full in the text itself (for news: the headlines and what happened), and links are stripped from replies — they are sent only when the person asks for one ("send me the link", "where can I see that?"). A published site's link still goes with its publish question, as before.
- **Media work: extract audio from a video.** New tools **extract_audio** (a direct video/audio file link → the audio file itself, attached to the reply by text: mp3, m4a or ogg) and **media_info** (length, size, tracks). They use ffmpeg on the server; the installer and Update now install it when missing, and the tool says so plainly when it is not there.
- **Connect accounts: the dead ends are fixed.** The Google connect link lived 15 minutes — Google's consent and "unverified app" screens often take longer, so connecting "didn't work"; it now lives an hour. A connect where Google returns no email no longer saves a broken empty account that made the *next* connect crash. The person's page only shows the Connect button when connect is really ready, and the dashboard Home now warns the admin when Connect accounts was never set up in Settings.
- **People opens on All.** Dashboard → People now shows **All** first (it opened on Waiting); Waiting / Approved / Blocked are still one tap away.

## 1.1.0 — 2026-11-18
- **Two separate doors on the sign-in page.** **My phone number**: type your number, a 6-digit code is texted to you, and you see your own chat page. **Admin**: username and password, for the dashboard only. The admin's own number signs in through the phone door like everyone and then also gets **Manage system** on that page. The password sign-in no longer opens any private chat (the "My chats" button is gone).
- **The dashboard no longer shows people's chats.** People → Details used to list a person's recent texts, and the first text of every person stayed visible after approval. Now texts are shown to the admin only while a person is waiting for approval (to decide), and the activity list no longer carries the text of what was sent to people. Notes and reminders are still shown (and can be deleted), as before.
- **One text per outage.** Settings → **Texts to me when Google Messages disconnects**: **Once** (default) = a single text, sent when Messages is back and has stayed up for 10 minutes, so a phone that goes on and off every few minutes is one problem, not a text every few minutes; **Never** = only the dashboard banner and the alert address; **Every time** = the old way.

## 1.0.9 — 2026-11-18
- **Texts that arrive while the server or the phone is away are answered.** The app remembers when it last had a working chat list. After a restart it answers the chats that got a text since then (before, they were dropped as "old history"). Anything older than 3 days is still left alone.
- **It heals itself when the phone is "not reachable".** After 90 seconds it reloads the Messages page; after 6 minutes it restarts the browser (at most every 15 minutes). Before, it waited, and one outage lasted about 50 hours.
- **Faster to take the session back and to recover.** "Use here" is tried every minute (was 5 minutes); an unreadable page is reloaded after 1 minute (was 3).
- **A failed text is not given up in seconds.** Tries are spaced 10 s, 30 s, 2, 5 and 10 minutes apart, and an ordinary reply gets 6 tries (sign-in codes and admin texts still 3).
- **No chat is forgotten when many change at once.** More than 5 changed chats: the rest are read on the next look.
- **A reboot just works.** The service waits up to 60 seconds for the internet before it starts, and systemd never stops restarting it. (Update now rewrites the service file.)

## 1.0.8 — 2026-11-12
- **Your page: all your chats.** Sign in with your phone number (a 6-digit code by text) and see your whole chat with the assistant, day by day, with "Show earlier messages" back to the first one. Chat from there too. Works on a phone and on a computer.
- **Connected accounts.** On the same page: **Connect Google** (Gmail, Calendar and Drive, read only). Then ask "what's on my calendar tomorrow?" or "any new email from the school?". The assistant only reads; it never sends, changes or deletes. Each person connects only their own account. The admin turns this on once in Settings → Connect accounts (Google) with a free Google Client ID and secret; the steps are on that card. Other kinds of accounts can be added the same way later.
- **Admin: the same page + "Manage system".** The admin signs in with his phone number like everyone, sees his own chats and accounts, and **Manage system** opens the dashboard and settings. From the dashboard, **My chats** goes the other way.
- **Access until a date.** People → Details → Access: **1 month** (again = one more month), **until a date**, or **No end date**. The list shows "until Dec 12" / "ended". After the end date the assistant sends ONE polite text ("Your access to … has ended. Please contact the admin…", editable in Settings) and then stops answering, reminders included. Extending or clearing the date turns it back on.
- **Faster replies, fewer AI calls.** Plain chat ("hi", "thanks", "good night") is answered with ONE AI call (if the AI says it needs a tool after all, it gets them: one more call; a "yes" to a question of the assistant always goes the full way). Questions that need the web get at most 3 rounds of searching (Settings → Tool rounds), then the answer; before, up to 12 calls for one message (that used up a free Gemini key's daily limit in 2 answers). A key at its per-minute limit is tried again after the time the provider says (or 20 s, was 60 s); a provider error rests a key 15 s (was 60 s). The key order and the "no AI key could answer" report are unchanged.
- **Speed card** (Settings): AI calls per reply, thinking time, waiting time and texting time of the last replies. Each reply also writes one line to the log with where its time went.
- **Old chats are not answered after a restart.** A chat whose last message is from before the start (an old unread spam from Oct 29 was answered after a restart on Nov 12) is left alone; a new text in it later is answered as usual.
- Sending: shorter pause between the parts of a long reply (250 ms, was 700 ms) and a faster look for the sent bubble.
- **New look, on phone and desktop** (the redesign): New look, on phone and desktop. The whole web side is redesigned in the colours of the logo: the admin sign-in, the dashboard (Home, People, Connect, Sites, AI keys, Settings) and the person's own web chat at `/me`. Phone: a clean sign-in card under the logo, big buttons and fields (no zooming in, no sideways scrolling from 360 px up), a bottom bar with clear icons. Desktop: sign-in with the logo on the left and the form on the right; the dashboard has its menu on the left and lays its cards out in two columns, with a sensible width. Sign-in for people: the web chat's sign-in now says "We text a 6-digit code to your phone". When the web chat is on, the admin sign-in page shows a link for people who came to chat: "Using the assistant? Open your chat →".
- The person's page on a computer: your name and the menu on the left, the chat in a wide, readable column (not a stretched phone screen).

## 1.0.7 — 2026-11-09
- **Tap and click right in the live picture.** On Connect, the picture of the server's browser now works like the page itself: tap (phone) or click (computer) anywhere and it is clicked at that exact spot. A blue dot shows where.
- **Tap a box and type.** Tapping a text box in the picture (like Google's email or password box) opens your phone's keyboard at once, and what you type goes straight into that box. Enter, Tab and ⌫ work too. Password letters stay hidden. On a computer, click the box and type.
- **Scroll in the picture.** Swipe up or down on the picture (phone) or use the mouse wheel (computer). Two fingers still zoom the picture.
- The "Send keys" box and the buttons under the picture are still there as a backup.
- The browser no longer brings back old tabs after a hard stop, and a window Google opens during sign-in shows in the picture.
- **Typing box fix.** Google Messages changed its typing box (it is no longer a plain text field), so replies could not be typed. Both kinds work now.
- **"Sent" means sent.** A reply counts as sent only when it shows in the chat without Google's clock ("Sending…"). If it left the typing box but is not shown as sent, the app looks at the chat again later (after 15 s, 30 s, 1, 2, 4, 8, 16 minutes) and never types it twice; if it is missing or "Not sent", it is sent again; still stuck after about 30 minutes, the admin gets the usual failed-text report.

## 1.0.6 — 2026-11-09
- **Google sign-in fix, again.** 1.0.4 hid the browser's "automated" flag with a small script, and Google spotted it: "Couldn't sign you in – This browser or app may not be secure". The script is gone; the flag is now the browser's own (and already off).
- **The browser runs visible** on a virtual screen on the server (the full Chromium, started like a normal browser, the app connects to it). The live picture, taps and typing in the dashboard work as before.
- **Connect shows which browser runs:** "Browser: full (visible)" or "Browser: basic". Settings shows the same at the bottom, with the version.
- **Update now installs what it needs.** The update installs the virtual screen (Xvfb) if it is missing, and the full Chromium if only part of it is there (before, any Chromium folder counted as installed). No command line needed.
- If the virtual screen can't start, the app still runs with the basic browser, says so, and tells you to press Update now.

## 1.0.4 — 2026-11-08
- **Google sign-in works from the server again.** 1.0.3 started a stripped-down headless browser, and Google refused to sign in from it ("Couldn't sign you in – This browser or app may not be secure"), whatever name it gave itself. 1.0.4 always starts the full browser the installer already puts on the server (still without a window), with a normal Chrome name and no automation marks. Checked live: Google accepts it.
- **Pairing goes straight to the QR code.** Connect → **Start pairing**. The QR code shows big in the dashboard. On the phone: Google Messages → profile picture → Device pairing → QR code scanner. If Google offers pairing with the Google account or a QR code, the QR code is chosen by itself, and "Remember this computer" is turned on.
- Google now wants the phone's Google account signed in once before it shows any QR code (every pairing page goes to sign-in first). If it asks, the dashboard says so and opens the server's browser live for that one sign-in; otherwise the live picture stays folded away.
- The QR code refreshes by itself every few seconds while it is up (Google changes it), and the dashboard says **Paired ✓** the moment the phone has scanned it. It stays paired after restarts and updates.
- If Google still refuses the sign-in, the dashboard says so in plain words ("Google refused the sign-in from the server's browser") instead of "Not signed in".

## 1.0.3 — 2026-11-08
- **Updates: "Checking…" always finishes.** Settings → Updates now ends every check within about 15 seconds with one of three answers: "Up to date (1.0.3)", "1.0.x available — Update now", or "Couldn't reach the update source" with a short reason (no answer in time, no version.json there, broken version.json, address not found). Before, the line stayed on "Checking…" whenever the check or another part of the Settings page failed or was slow, and "Check again" showed no progress.
- The check asks every source at the same time with one time limit, shares one look when two checks run together, and skips GitHub's few-minutes-old cached copy.
- If "Update now" did not start on the server, the page says so (with `sudo messageassistant update`) instead of "starting…" forever.
- **Editable update source** (Settings → Updates → Update source, like My Assistant): the default GitHub folder or another https address; a GitHub repo link works too (its /docs folder). Save, Reset to default, and the order the sources are tried. The root updater uses the saved address too; it still checks the sha256 of every download and never installs an older or the same version.
- `sudo messageassistant update-source show|set <url>|reset`.
- **Logo no longer fills the page.** On a phone, 1.0.2 could show the old logo full width above Updates: the page was new but the phone kept the old style and logo files. Now every page asks for its files with `?v=<version>` (style, script, logo, icons, manifest), pages are never cached, each logo has its own small size (28 px in the header, 72 px on sign-in) even if the style file fails, and the dashboard reloads itself once after an update. App icon, favicon and home-screen icons are the new logo everywhere.

## 1.0.2 — 2026-11-08
- **Websites for every approved person:** they ask by text, the assistant builds HTML/CSS/JavaScript in their own folder and sends a phone-size picture (no code in the chat; code only on request, as a file). Each person's files are separate (no `..`, no symlinks out, no hidden files).
- **Publishing with one YES:** one question with the link; a code only when two are waiting; same site again replaces the old request; 30-minute expiry. Live at `/sites/<name><#>-<site>/` with a 404 page (or the site's own `404.html`). Unpublish by text or from the dashboard.
- **Admin setting "Site publishing"** (Dashboard → Sites, or `sudo messageassistant sites-approval on|off|show`): off = the person's YES publishes; on = you approve each publish (picture + private preview link by text and in the dashboard; reply YES/NO or tap Approve/Reject).
- **Who can build sites**: everyone, only chosen people, or nobody. Limits per person: 50 MB and 5 sites (changeable).
- **Dashboard → Sites**: every published site (person, name, link, size, date) with Unpublish; requests waiting for you.
- **Pictures over Messages**: the assistant can send a picture (it falls back to a private link if the page won't take it).
- **Web chat for each person** at `https://<address>/me`: they sign in with their phone number and a texted code (approved people only), see their own chat (texts, pictures, site links) and chat from there; every answer is also texted, and texts from the phone show up there. Same one-YES rules. Admin switch: Settings, or `sudo messageassistant portal on|off`.
- **New logo.**
- **Updates:** release notes in the dashboard, the update log live while it runs, a once-a-day check (badge + one text; never installs), `sudo messageassistant check-update`.

## 1.0.1 — 2026-11-05
- **Startup fix:** the service now starts through `/opt/messageassistant/current` (1.0.0 compared plain paths, so through the
  `current` link it never started and restarted in a loop). It now compares real paths.
- **Update from the dashboard:** Settings → Updates → **Update now** (or `sudo messageassistant update`). Nothing updates by itself. It installs only a newer version
  (sha256-checked, never a downgrade): database backup → `releases/<version>` → switch `current` → restart → `/healthz`.
  If the new version does not answer, it goes back to the previous release by itself. Logs: `sudo messageassistant logs`.
- **Dashboard:** Settings → Updates: this server's version and the latest, **Update now** and **Check again**.
- **Installer/updater repair the service file:** `ExecStart` always points at `current/src/server.js` (a hand-edited
  `releases/<version>` path is fixed).
- **Your settings are kept:** an update never changes `/etc/messageassistant/env`, the Caddy files or your data.
  Running the installer again keeps `MSA_HOST`, `MSA_PUBLIC_URL`, `MSA_PORT` and any other lines you added.
- New command: `sudo messageassistant version`.

## 1.0.0 — 2026-11-03
- First release.
